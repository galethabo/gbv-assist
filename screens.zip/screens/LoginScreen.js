// LoginScreen.js - Fixed GBV Version
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ImageBackground,
  Image,
  Vibration
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import * as Haptics from 'expo-haptics';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../firebase';
import { doc, setDoc, updateProfile } from 'firebase/firestore';

const { width, height } = Dimensions.get('window');

// Unified haptic feedback handler
const triggerHaptic = async (type = 'medium') => {
  try {
    if (!Haptics || !Haptics.impactAsync) {
      Vibration.vibrate(50); // Fallback vibration
      return;
    }

    const hapticMap = {
      light: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
      medium: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium),
      heavy: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy),
      success: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success),
      error: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error),
      warning: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)
    };

    const handler = hapticMap[type] || hapticMap.medium;
    await handler();
  } catch (error) {
    console.log("Haptic feedback failed:", error);
    Vibration.vibrate(50); // Fallback vibration
  }
};

export default function LoginScreen({ navigation }) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [loginCredentials, setLoginCredentials] = useState({
    email: '',
    password: ''
  });
  
  const [registerData, setRegisterData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleLogin = async () => {
    if (!loginCredentials.email || !loginCredentials.password) {
      Alert.alert('Error', 'Please enter both email and password');
      await triggerHaptic('error');
      return;
    }

    setIsLoading(true);
    await triggerHaptic('medium');
    
    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        loginCredentials.email,
        loginCredentials.password
      );
      
      console.log('Login successful:', userCredential.user.uid);
      await triggerHaptic('success');
      
      // Navigation will be handled by AuthContext
    } catch (error) {
      console.error('Login error:', error);
      let errorMessage = 'Failed to login. Please try again.';
      
      if (error.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email address.';
      } else if (error.code === 'auth/user-disabled') {
        errorMessage = 'This account has been disabled.';
      } else if (error.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email.';
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Incorrect password.';
      } else if (error.code === 'auth/network-request-failed') {
        errorMessage = 'Network error. Please check your internet connection.';
      } else if (error.code === 'auth/too-many-requests') {
        errorMessage = 'Too many failed attempts. Please try again later.';
      }
      
      Alert.alert('Login Error', errorMessage);
      await triggerHaptic('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!registerData.name || !registerData.email || !registerData.password) {
      Alert.alert('Error', 'Please fill in all fields');
      await triggerHaptic('error');
      return;
    }

    if (registerData.password !== registerData.confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      await triggerHaptic('error');
      return;
    }

    if (registerData.password.length < 6) {
      Alert.alert('Error', 'Password should be at least 6 characters');
      await triggerHaptic('error');
      return;
    }

    setIsLoading(true);
    await triggerHaptic('medium');

    try {
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        registerData.email,
        registerData.password
      );

      // Update user profile with display name
      await updateProfile(userCredential.user, {
        displayName: registerData.name
      });

      // Create user document in Firestore
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        name: registerData.name,
        email: registerData.email.toLowerCase(),
        authMethod: 'email',
        createdAt: new Date(),
        notifications: true,
        locationEnabled: true,
        darkMode: false,
        lastLogin: new Date()
      });

      console.log('Registration successful:', userCredential.user.uid);
      await triggerHaptic('success');
      
      Alert.alert(
        'Success!', 
        'Account created successfully!',
        [{ text: 'OK' }]
      );

    } catch (error) {
      console.error('Registration error:', error);
      let errorMessage = 'Failed to create account. Please try again.';
      
      if (error.code === 'auth/email-already-in-use') {
        errorMessage = 'This email is already registered. Please use a different email or login.';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email address format.';
      } else if (error.code === 'auth/weak-password') {
        errorMessage = 'Password is too weak. Please use a stronger password.';
      } else if (error.code === 'auth/network-request-failed') {
        errorMessage = 'Network error. Please check your internet connection.';
      } else if (error.code === 'auth/operation-not-allowed') {
        errorMessage = 'Email/password registration is not enabled. Please contact support.';
      }
      
      Alert.alert('Registration Error', errorMessage);
      await triggerHaptic('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    const email = isRegistering ? registerData.email : loginCredentials.email;
    
    if (!email) {
      Alert.alert('Error', 'Please enter your email address');
      await triggerHaptic('error');
      return;
    }

    setIsLoading(true);
    await triggerHaptic('medium');

    try {
      await sendPasswordResetEmail(auth, email);
      Alert.alert(
        'Password Reset Email Sent',
        'Please check your email for instructions to reset your password.'
      );
      await triggerHaptic('success');
    } catch (error) {
      console.error('Password reset error:', error);
      let errorMessage = 'Failed to send reset email. Please try again.';
      
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email address.';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email address format.';
      }
      
      Alert.alert('Error', errorMessage);
      await triggerHaptic('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestAccess = async () => {
    await triggerHaptic('medium');
    navigation.navigate('Home');
  };

  const toggleForm = () => {
    setIsRegistering(!isRegistering);
    triggerHaptic('light');
  };

  return (
    <ImageBackground
      source={require('../assets/images/gbv-background.jpg')} // Add your GBV background image
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <StatusBar style="light" />
      <LinearGradient
        colors={['rgba(106, 13, 173, 0.8)', 'rgba(74, 0, 128, 0.6)']} // GBV purple theme
        style={styles.gradientOverlay}
      >
        <KeyboardAvoidingView 
          style={styles.container} 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <ScrollView 
            contentContainerStyle={styles.scrollContainer}
            showsVerticalScrollIndicator={false}
          >
            {/* Header Section */}
            <Animatable.View 
              animation="fadeInDown" 
              duration={1000}
              style={styles.header}
            >
              <View style={styles.logoContainer}>
                <Ionicons name="shield-checkmark" size={60} color="white" />
              </View>
              <Text style={styles.title}>GBV Assist</Text>
              <Text style={styles.subtitle}>Support for Survivors</Text>
            </Animatable.View>

            {/* Form Section */}
            <Animatable.View 
              animation="fadeInUp" 
              duration={1000}
              delay={300}
              style={styles.formContainer}
            >
              <View style={styles.formCard}>
                <Text style={styles.formTitle}>
                  {isRegistering ? 'Create Account' : 'Welcome Back'}
                </Text>
                <Text style={styles.formSubtitle}>
                  {isRegistering ? 'Join our support community' : 'Sign in to your account'}
                </Text>

                {isRegistering && (
                  <Animatable.View animation="fadeInRight" duration={500}>
                    <View style={styles.inputContainer}>
                      <Ionicons name="person-outline" size={20} color="#666" style={styles.inputIcon} />
                      <TextInput
                        style={styles.input}
                        placeholder="Full Name"
                        placeholderTextColor="#999"
                        value={registerData.name}
                        onChangeText={(text) => setRegisterData({...registerData, name: text})}
                        autoCapitalize="words"
                        editable={!isLoading}
                      />
                    </View>
                  </Animatable.View>
                )}

                <View style={styles.inputContainer}>
                  <Ionicons name="mail-outline" size={20} color="#666" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Email Address"
                    placeholderTextColor="#999"
                    value={isRegistering ? registerData.email : loginCredentials.email}
                    onChangeText={(text) => {
                      if (isRegistering) {
                        setRegisterData({...registerData, email: text});
                      } else {
                        setLoginCredentials({...loginCredentials, email: text});
                      }
                    }}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    editable={!isLoading}
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Ionicons name="lock-closed-outline" size={20} color="#666" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { flex: 1 }]}
                    placeholder={isRegistering ? "Password (min 6 characters)" : "Password"}
                    placeholderTextColor="#999"
                    value={isRegistering ? registerData.password : loginCredentials.password}
                    onChangeText={(text) => {
                      if (isRegistering) {
                        setRegisterData({...registerData, password: text});
                      } else {
                        setLoginCredentials({...loginCredentials, password: text});
                      }
                    }}
                    secureTextEntry={!showPassword}
                    editable={!isLoading}
                  />
                  <TouchableOpacity
                    onPress={() => setShowPassword(!showPassword)}
                    style={styles.eyeIcon}
                    disabled={isLoading}
                  >
                    <Ionicons 
                      name={showPassword ? "eye-outline" : "eye-off-outline"} 
                      size={20} 
                      color="#666" 
                    />
                  </TouchableOpacity>
                </View>

                {isRegistering && (
                  <Animatable.View animation="fadeInRight" duration={500} delay={200}>
                    <View style={styles.inputContainer}>
                      <Ionicons name="lock-closed-outline" size={20} color="#666" style={styles.inputIcon} />
                      <TextInput
                        style={[styles.input, { flex: 1 }]}
                        placeholder="Confirm Password"
                        placeholderTextColor="#999"
                        value={registerData.confirmPassword}
                        onChangeText={(text) => setRegisterData({...registerData, confirmPassword: text})}
                        secureTextEntry={!showConfirmPassword}
                        editable={!isLoading}
                      />
                      <TouchableOpacity
                        onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                        style={styles.eyeIcon}
                        disabled={isLoading}
                      >
                        <Ionicons 
                          name={showConfirmPassword ? "eye-outline" : "eye-off-outline"} 
                          size={20} 
                          color="#666" 
                        />
                      </TouchableOpacity>
                    </View>
                  </Animatable.View>
                )}

                {!isRegistering && (
                  <TouchableOpacity
                    onPress={handleForgotPassword}
                    disabled={isLoading}
                    style={styles.forgotPasswordButton}
                  >
                    <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
                  </TouchableOpacity>
                )}

                <TouchableOpacity
                  style={[styles.submitButton, isLoading && styles.disabledButton]}
                  onPress={isRegistering ? handleRegister : handleLogin}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Text style={styles.submitButtonText}>Please wait...</Text>
                  ) : (
                    <Text style={styles.submitButtonText}>
                      {isRegistering ? 'Create Account' : 'Sign In'}
                    </Text>
                  )}
                </TouchableOpacity>

                {/* Guest Access Button */}
                <TouchableOpacity
                  style={styles.guestButton}
                  onPress={handleGuestAccess}
                  disabled={isLoading}
                >
                  <Text style={styles.guestButtonText}>
                    Continue as Guest
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.switchButton}
                  onPress={toggleForm}
                  disabled={isLoading}
                >
                  <Text style={styles.switchButtonText}>
                    {isRegistering 
                      ? 'Already have an account? Sign In' 
                      : "Don't have an account? Sign Up"
                    }
                  </Text>
                </TouchableOpacity>

                {/* Emergency Access */}
                <View style={styles.emergencySection}>
                  <Text style={styles.emergencyText}>
                    Need immediate help? Emergency resources are available to everyone.
                  </Text>
                  <TouchableOpacity
                    style={styles.emergencyButton}
                    onPress={() => navigation.navigate('Emergency')}
                  >
                    <Ionicons name="warning" size={16} color="white" />
                    <Text style={styles.emergencyButtonText}>Emergency Resources</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Animatable.View>
          </ScrollView>
        </KeyboardAvoidingView>
      </LinearGradient>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  gradientOverlay: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.9)',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  formCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    padding: 30,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6A0DAD',
    textAlign: 'center',
    marginBottom: 8,
  },
  formSubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    marginBottom: 20,
    paddingBottom: 10,
  },
  inputIcon: {
    marginRight: 15,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    paddingVertical: 5,
  },
  eyeIcon: {
    padding: 5,
  },
  forgotPasswordButton: {
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  forgotPasswordText: {
    color: '#6A0DAD',
    fontSize: 14,
    fontWeight: '500',
  },
  submitButton: {
    backgroundColor: '#6A0DAD',
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#6A0DAD',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  disabledButton: {
    opacity: 0.7,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  guestButton: {
    backgroundColor: 'rgba(106, 13, 173, 0.1)',
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#6A0DAD',
  },
  guestButtonText: {
    color: '#6A0DAD',
    fontSize: 16,
    fontWeight: 'bold',
  },
  switchButton: {
    marginTop: 20,
    alignItems: 'center',
  },
  switchButtonText: {
    color: '#6A0DAD',
    fontSize: 14,
    fontWeight: '500',
  },
  emergencySection: {
    marginTop: 25,
    padding: 15,
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#FF3B30',
  },
  emergencyText: {
    color: '#666',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 16,
  },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF3B30',
    padding: 10,
    borderRadius: 8,
  },
  emergencyButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 8,
  },
});