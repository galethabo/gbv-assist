// ChatScreen.js - FIXED VERSION
import React, { useState, useRef, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TextInput, 
  TouchableOpacity, 
  KeyboardAvoidingView, 
  Platform 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, setDoc, onSnapshot, query, orderBy } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// Simple rule-based chatbot
const chatbotResponses = {
  greeting: "Hello, I'm here to help. How can I assist you today?",
  help: "I can help you with information about gender-based violence, reporting procedures, and available resources. What would you like to know?",
  reporting: "You can report an incident anonymously through our app. Go to the 'Report' tab to submit a report. All information is confidential.",
  emergency: "If you're in immediate danger, please call 10111 for the South African Police. You can also use the 'Emergency' tab for quick access to help.",
  resources: "We can connect you with legal aid, counseling services, and shelters. Check the 'Resources' tab for services near you.",
  legal: "For legal assistance, you can contact Legal Aid South Africa at 0800 110 110 or visit their website at www.legal-aid.co.za",
  counseling: "For counseling support, you can contact Lifeline at 0861 322 322 or the South African Depression and Anxiety Group at 0800 456 789",
  shelter: "For shelter assistance, you can contact the People Against Women Abuse (POWA) at 011 642 4345 or visit www.powa.co.za",
  default: "I'm sorry, I don't understand. Could you please rephrase your question? I can help with information about reporting, emergency contacts, legal aid, counseling, and shelters."
};

const getBotResponse = (message) => {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return chatbotResponses.greeting;
  } else if (lowerMessage.includes('help')) {
    return chatbotResponses.help;
  } else if (lowerMessage.includes('report') || lowerMessage.includes('incident')) {
    return chatbotResponses.reporting;
  } else if (lowerMessage.includes('emergency') || lowerMessage.includes('danger') || lowerMessage.includes('urgent')) {
    return chatbotResponses.emergency;
  } else if (lowerMessage.includes('resource') || lowerMessage.includes('service') || lowerMessage.includes('support')) {
    return chatbotResponses.resources;
  } else if (lowerMessage.includes('legal') || lowerMessage.includes('lawyer') || lowerMessage.includes('attorney')) {
    return chatbotResponses.legal;
  } else if (lowerMessage.includes('counseling') || lowerMessage.includes('therapy') || lowerMessage.includes('psychologist')) {
    return chatbotResponses.counseling;
  } else if (lowerMessage.includes('shelter') || lowerMessage.includes('housing') || lowerMessage.includes('accommodation')) {
    return chatbotResponses.shelter;
  } else {
    return chatbotResponses.default;
  }
};

export default function ChatScreen() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [sessionId, setSessionId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef(null);
  const auth = getAuth();

  useEffect(() => {
    const initializeChat = async () => {
      try {
        const user = auth.currentUser;
        const session = user ? user.uid : `anon_${Date.now()}`;
        setSessionId(session);
        
        // Initialize chat session in Firebase
        const sessionRef = doc(db, 'chat_sessions', session);
        await setDoc(sessionRef, {
          userId: session,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          status: 'active'
        }, { merge: true });

        // Load existing messages
        const messagesQuery = query(
          collection(db, 'chat_sessions', session, 'messages'),
          orderBy('timestamp', 'asc')
        );

        const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
          const loadedMessages = [];
          snapshot.forEach((doc) => {
            const data = doc.data();
            loadedMessages.push({
              id: doc.id,
              text: data.text,
              sender: data.sender,
              timestamp: data.timestamp
            });
          });
          setMessages(loadedMessages);
        });

        // Add welcome message if no messages exist
        if (messages.length === 0) {
          const welcomeMessage = {
            text: "Hello, I'm here to help. How can I assist you today?",
            sender: 'bot',
            timestamp: serverTimestamp()
          };
          await saveMessageToFirebase(welcomeMessage);
        }

        return () => unsubscribe();
      } catch (error) {
        console.error('Error initializing chat:', error);
      }
    };

    initializeChat();
  }, []);

  const sendMessage = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMessage = {
      text: inputText.trim(),
      sender: 'user',
      timestamp: serverTimestamp()
    };

    setInputText('');
    setIsLoading(true);
    
    try {
      await saveMessageToFirebase(userMessage);

      // Simulate bot thinking
      setTimeout(async () => {
        const botResponse = {
          text: getBotResponse(inputText),
          sender: 'bot',
          timestamp: serverTimestamp()
        };
        
        await saveMessageToFirebase(botResponse);
        setIsLoading(false);
      }, 1500);
    } catch (error) {
      console.error('Error sending message:', error);
      setIsLoading(false);
      Alert.alert('Error', 'Failed to send message. Please try again.');
    }
  };

  const saveMessageToFirebase = async (message) => {
    try {
      if (!sessionId) return;

      const messagesRef = collection(db, 'chat_sessions', sessionId, 'messages');
      await addDoc(messagesRef, {
        text: message.text,
        sender: message.sender,
        timestamp: message.timestamp
      });

      // Update session timestamp
      const sessionRef = doc(db, 'chat_sessions', sessionId);
      await setDoc(sessionRef, {
        updatedAt: serverTimestamp()
      }, { merge: true });
    } catch (error) {
      console.error('Error saving message to Firebase:', error);
      throw error;
    }
  };

  const renderMessage = ({ item }) => {
    const timestamp = item.timestamp?.toDate ? item.timestamp.toDate() : new Date();
    
    return (
      <View style={[
        styles.messageBubble,
        item.sender === 'user' ? styles.userBubble : styles.botBubble
      ]}>
        <Text style={[
          styles.messageText,
          item.sender === 'user' ? styles.userMessageText : styles.botMessageText
        ]}>
          {item.text}
        </Text>
        <Text style={styles.timestamp}>
          {timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={90}
    >
      <View style={styles.chatContainer}>
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={item => item.id}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          onLayout={() => flatListRef.current?.scrollToEnd({ animated: true })}
          contentContainerStyle={styles.messagesList}
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Type your message here..."
          placeholderTextColor="#999"
          multiline
          maxLength={500}
          onSubmitEditing={sendMessage}
          returnKeyType="send"
          editable={!isLoading}
        />
        <TouchableOpacity 
          style={[
            styles.sendButton, 
            (!inputText.trim() || isLoading) && styles.sendButtonDisabled
          ]} 
          onPress={sendMessage}
          disabled={!inputText.trim() || isLoading}
        >
          {isLoading ? (
            <Text style={styles.sendButtonText}>...</Text>
          ) : (
            <Ionicons name="send" size={20} color="white" />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          This is an automated support chatbot. For immediate help, please use the Emergency tab.
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  chatContainer: {
    flex: 1,
  },
  messagesList: {
    padding: 15,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 20,
    marginBottom: 10,
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#6A0DAD',
    borderBottomRightRadius: 5,
  },
  botBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#E8E8E8',
    borderBottomLeftRadius: 5,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  userMessageText: {
    color: 'white',
  },
  botMessageText: {
    color: '#333',
  },
  timestamp: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 5,
    alignSelf: 'flex-end',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 12,
    maxHeight: 100,
    marginRight: 10,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  sendButton: {
    backgroundColor: '#6A0DAD',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: '#ccc',
  },
  sendButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disclaimer: {
    padding: 12,
    backgroundColor: '#FFF4F4',
    borderTopWidth: 1,
    borderTopColor: '#FFDDDD',
  },
  disclaimerText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    lineHeight: 16,
  },
});